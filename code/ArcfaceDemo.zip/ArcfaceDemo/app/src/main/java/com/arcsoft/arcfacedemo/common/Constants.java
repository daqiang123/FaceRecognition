package com.arcsoft.arcfacedemo.common;

public class Constants {
    public static final String APP_ID = "4V7ySy5Lm7sUBeyADTyxiQ17VTXMJfjfU1MPS1uj41ch";
    public static final String SDK_KEY = "DyiFSCaQwWWdfeUKTkcVajPd3qVGYk6xKP67RKS57DEt";
}
