-- ----------------------------
-- 增加人脸字段
-- ----------------------------
alter table user_face_info add face longblob;
