package com.itboyst.facedemo.service;

import com.itboyst.facedemo.domain.UserFaceInfo;


public interface UserFaceInfoService {

    int insertSelective(UserFaceInfo userFaceInfo);

}
