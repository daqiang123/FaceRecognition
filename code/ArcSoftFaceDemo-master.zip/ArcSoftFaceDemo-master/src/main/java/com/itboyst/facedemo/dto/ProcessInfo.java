package com.itboyst.facedemo.dto;

/**
 * @Author: st7251
 * @Date: 2018/12/3 9:55
 */
public class ProcessInfo {
    private Integer age;
    private Integer gender;

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }
}
