package com.itboyst.facedemo.dao.mapper;

import com.itboyst.facedemo.domain.UserFaceInfo;
import org.nico.ourbatis.mapper.SimpleMapper;


public interface UserFaceInfoMapper extends SimpleMapper<UserFaceInfo, Integer> {




}
